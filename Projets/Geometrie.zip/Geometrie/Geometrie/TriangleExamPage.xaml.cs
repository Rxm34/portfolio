﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace Geometrie
{
    public partial class TriangleExamPage : Page
    {
        public event EventHandler<(bool isCorrect, string userAnswer, string correctAnswer, string questionText)> OnVerificationCompleted;
        private DispatcherTimer timer;
        private ClasseTriangle triangle = new ClasseTriangle();
        private ClasseCalcul calcul = new ClasseCalcul();  // Utilisation de ClasseCalcul
        private bool estPerimetreVisible;

        public TriangleExamPage()
        {
            InitializeComponent();
            triangle.Init();

            TxtCoteA.Text = triangle.C1.ToString();
            TxtCoteB.Text = triangle.C2.ToString();
            TxtBase.Text = triangle.BaseRecalculee.ToString();
            TxtHauteur.Text = triangle.Haut.ToString();

            triangle.Dessin(DrawingCanvas, TxtCoteA, TxtCoteB, TxtBase);

            Random random = new Random();
            int cacherPerimetre = random.Next(2);
            estPerimetreVisible = cacherPerimetre == 1;

            if (!estPerimetreVisible)
            {
                TxtPerimetre.Visibility = Visibility.Collapsed;
                BtnVerifierPerimetre.Visibility = Visibility.Collapsed;
                TxtPerimetreReponse.Visibility = Visibility.Collapsed;
                LblPerimetre.Visibility = Visibility.Collapsed;
            }
            else
            {
                TxtSurface.Visibility = Visibility.Collapsed;
                BtnVerifierSurface.Visibility = Visibility.Collapsed;
                TxtSurfaceReponse.Visibility = Visibility.Collapsed;
                LblSurface.Visibility = Visibility.Collapsed;
            }

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(5);
            timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            OnVerificationCompleted?.Invoke(this, (
                false,
                "Aucune réponse",
                "?",
                "Temps écoulé"
            ));
        }

        private void BtnVerifierPerimetre_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int perimetreCorrect = Convert.ToInt32(triangle.Perimetre());
                int perimetreUtilisateur = Convert.ToInt32(TxtPerimetre.Text);

                bool isCorrect = perimetreCorrect == perimetreUtilisateur;
                TxtPerimetreReponse.Text = isCorrect ? "Bonne réponse !" : "Mauvaise réponse !";
                TxtPerimetreReponse.Foreground = isCorrect ? Brushes.Green : Brushes.Red;
                TxtPerimetreReponse.Visibility = Visibility.Visible;

                // Calcul de la réponse avec la classe Calcul
                OnVerificationCompleted?.Invoke(this, (
                    isCorrect,
                    perimetreUtilisateur.ToString(),
                    perimetreCorrect.ToString(),
                    $"Périmètre d’un triangle de côté {triangle.C1}, {triangle.C2} et de base {triangle.BaseRecalculee}"
                ));
            }
            catch (FormatException)
            {
                MessageBox.Show("Pas de nombres à virgules et pas de lettres.");
            }
        }

        private void BtnVerifierSurface_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int surfaceCorrecte = triangle.Surface();
                int surfaceUtilisateur = Convert.ToInt32(TxtSurface.Text);

                bool isCorrect = surfaceCorrecte == surfaceUtilisateur;
                TxtSurfaceReponse.Text = isCorrect ? "Bonne réponse !" : "Mauvaise réponse !";
                TxtSurfaceReponse.Foreground = isCorrect ? Brushes.Green : Brushes.Red;
                TxtSurfaceReponse.Visibility = Visibility.Visible;

                // Calcul de la réponse avec la classe Calcul
                OnVerificationCompleted?.Invoke(this, (
                    isCorrect,
                    surfaceUtilisateur.ToString(),
                    surfaceCorrecte.ToString(),
                    $"Surface d’un triangle de base {triangle.BaseRecalculee} et de hauteur {triangle.Haut}"
                ));
            }
            catch (FormatException)
            {
                MessageBox.Show("Pas de nombres à virgules et pas de lettres.");
            }
        }
    }
}
