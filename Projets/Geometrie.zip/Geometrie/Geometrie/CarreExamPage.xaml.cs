﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace Geometrie
{
    public partial class CarreExamPage : Page
    {
        public event EventHandler<(bool isCorrect, string userAnswer, string correctAnswer, string questionText)> OnVerificationCompleted;
        private DispatcherTimer timer;
        private ClasseCarre carre = new ClasseCarre();
        private ClasseCalcul calcul = new ClasseCalcul();  // Utilisation de ClasseCalcul
        private bool estPerimetreVisible;

        public CarreExamPage()
        {
            InitializeComponent();
            carre.Init();
            TxtCote.Text = carre.UneValeur.ToString();

            Random random = new Random();
            int cacherPerimetre = random.Next(2);
            estPerimetreVisible = cacherPerimetre == 1;

            if (!estPerimetreVisible)
            {
                TxtPerimetre.Visibility = Visibility.Collapsed;
                BtnVerifierPerimetre.Visibility = Visibility.Collapsed;
                TxtBlockResultatPerimetre.Visibility = Visibility.Collapsed;
                LblPerimetre.Visibility = Visibility.Collapsed;
            }
            else
            {
                TxtSurface.Visibility = Visibility.Collapsed;
                BtnVerifierSurface.Visibility = Visibility.Collapsed;
                TxtBlockResultatSurface.Visibility = Visibility.Collapsed;
                LblSurface.Visibility = Visibility.Collapsed;
            }

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(5);
            timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            OnVerificationCompleted?.Invoke(this, (false, "Aucune réponse", "?", "Temps écoulé"));
        }

        private void DrawingCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            carre.Dessin(DrawingCanvas, TxtCote);
        }

        private void BtnVerifierPerimetre_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int cote = Convert.ToInt32(TxtCote.Text);
                carre.UneValeur = cote;
                int perimetreCorrect = Convert.ToInt32(carre.Perimetre());
                int perimetreUtilisateur = Convert.ToInt32(TxtPerimetre.Text);

                bool isCorrect = perimetreCorrect == perimetreUtilisateur;
                TxtBlockResultatPerimetre.Text = isCorrect ? "Bonne réponse !" : "Mauvaise réponse !";
                TxtBlockResultatPerimetre.Foreground = isCorrect ? Brushes.Green : Brushes.Red;
                TxtBlockResultatPerimetre.Visibility = Visibility.Visible;

                // Calcul de la réponse avec la classe Calcul
                OnVerificationCompleted?.Invoke(this, (
                    isCorrect,
                    perimetreUtilisateur.ToString(),
                    perimetreCorrect.ToString(),
                    $"Périmètre d’un carré de côté {cote}"
                ));
            }
            catch (FormatException)
            {
                MessageBox.Show("Pas de nombres à virgules et pas de lettres.");
            }
        }

        private void BtnVerifierSurface_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int cote = Convert.ToInt32(TxtCote.Text);
                carre.UneValeur = cote;
                int surfaceCorrecte = Convert.ToInt32(carre.Surface());
                int surfaceUtilisateur = Convert.ToInt32(TxtSurface.Text);

                bool isCorrect = surfaceCorrecte == surfaceUtilisateur;
                TxtBlockResultatSurface.Text = isCorrect ? "Bonne réponse !" : "Mauvaise réponse !";
                TxtBlockResultatSurface.Foreground = isCorrect ? Brushes.Green : Brushes.Red;
                TxtBlockResultatSurface.Visibility = Visibility.Visible;

                // Calcul de la réponse avec la classe Calcul
                OnVerificationCompleted?.Invoke(this, (
                    isCorrect,
                    surfaceUtilisateur.ToString(),
                    surfaceCorrecte.ToString(),
                    $"Surface d’un carré de côté {cote}"
                ));
            }
            catch (FormatException)
            {
                MessageBox.Show("Pas de nombres à virgules et pas de lettres.");
            }
        }
    }
}
