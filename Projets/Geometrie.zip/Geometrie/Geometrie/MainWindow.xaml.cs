﻿using Geometrie;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace Geometrie
{
    public partial class MainWindow : Window
    {
        public int bonnesReponses = 0;
        public int pagesVisitees = 0;
        private List<Type> pages;
        private Random random;
        public List<(string questionText, string userAnswer, string correctAnswer, string detailedCalculation)> recapitulatif = new List<(string, string, string, string)>();

        private ClasseCarre carre;
        private ClasseRectangle rectangle;
        private ClasseTriangle triangle;
        private ClasseCercle cercle;

        public MainWindow()
        {
            InitializeComponent();
            pages = new List<Type>
            {
                typeof(CarreExamPage),
                typeof(RectangleExamPage),
                typeof(TriangleExamPage),
                typeof(CercleExamPage)
            };
            random = new Random();

            // Initialisation des classes
            carre = new ClasseCarre();
            rectangle = new ClasseRectangle();
            triangle = new ClasseTriangle();
            cercle = new ClasseCercle();
        }

        private void BtnEntrainement_Click(object sender, RoutedEventArgs e)
        {
            NavigationFrame.Navigate(new AccueilPage());
        }

        public void BtnEvaluation_Click(object sender, RoutedEventArgs e)
        {
            bonnesReponses = 0;
            pagesVisitees = 0;
            recapitulatif.Clear(); // Réinitialiser le résumé
            NavigateToRandomPage();
        }

        private void NavigateToRandomPage()
        {
            if (pagesVisitees < 20)
            {
                int pageIndex = random.Next(pages.Count);
                Type selectedPage = pages[pageIndex];
                Page page = (Page)Activator.CreateInstance(selectedPage);

                if (page is CarreExamPage carrePage)
                {
                    carrePage.OnVerificationCompleted += CarrePage_OnVerificationCompleted;
                }
                else if (page is RectangleExamPage rectanglePage)
                {
                    rectanglePage.OnVerificationCompleted += RectanglePage_OnVerificationCompleted;
                }
                else if (page is TriangleExamPage trianglePage)
                {
                    trianglePage.OnVerificationCompleted += TrianglePage_OnVerificationCompleted;
                }
                else if (page is CercleExamPage cerclePage)
                {
                    cerclePage.OnVerificationCompleted += CerclePage_OnVerificationCompleted;
                }

                NavigationFrame.Navigate(page);
                pagesVisitees++;
            }
            else
            {
                NavigationFrame.Navigate(new ResultatPage(bonnesReponses, recapitulatif));
            }
        }

        private void CarrePage_OnVerificationCompleted(object sender, (bool isCorrect, string userAnswer, string correctAnswer, string questionText) e)
        {
            if (e.isCorrect) bonnesReponses++;

            if (sender is CarreExamPage carrePage)
            {
                // Récupérer la valeur du côté du carré
                int cote = int.Parse(carrePage.TxtCote.Text);
                string detailedCalculation;

                // Déterminer la question (Périmètre ou Surface)
                if (e.questionText.ToLower().Contains("surface"))
                {
                    // Calcul de la surface
                    double surface = carre.Multiplication(cote,cote);  // Surface = côté × côté
                    surface = Math.Round(surface);  // Arrondir le résultat à l'entier le plus proche
                    detailedCalculation = $"Surface = côté × côté = {cote} × {cote} = {surface}";
                    e.correctAnswer = surface.ToString();
                }
                else if (e.questionText.ToLower().Contains("périmètre"))
                {
                    // Calcul du périmètre
                    double perimetre = carre.Multiplication(4,cote);  // Périmètre = 4 × côté
                    perimetre = Math.Round(perimetre);  // Arrondir le résultat à l'entier le plus proche
                    detailedCalculation = $"Périmètre = 4 × côté = 4 × {cote} = {perimetre}";
                    e.correctAnswer = perimetre.ToString();
                }
                else
                {
                    detailedCalculation = "Formule non reconnue.";
                }

                recapitulatif.Add((
                    $"[Carré] {e.questionText}",
                    e.userAnswer,
                    e.correctAnswer,
                    detailedCalculation
                ));
            }

            NavigateToRandomPage();
        }

        private void RectanglePage_OnVerificationCompleted(object sender, (bool isCorrect, string userAnswer, string correctAnswer, string questionText) e)
        {
            if (e.isCorrect) bonnesReponses++;

            if (sender is RectangleExamPage rectanglePage)
            {
                // Récupérer les valeurs de longueur et largeur
                int longueur = int.Parse(rectanglePage.TxtLongueur.Text);
                int largeur = int.Parse(rectanglePage.TxtLargeur.Text);

                string detailedCalculation;

                if (e.questionText.ToLower().Contains("périmètre"))
                {
                    // Calcul du périmètre
                    double perimetre = rectangle.Multiplication(rectangle.Addition(longueur,largeur),2);  // Périmètre = 2 × (longueur + largeur)
                    perimetre = Math.Round(perimetre);  // Arrondir le résultat à l'entier le plus proche
                    detailedCalculation = $"Périmètre = 2 × (longueur + largeur) = 2 × ({longueur} + {largeur}) = {perimetre}";
                    e.correctAnswer = perimetre.ToString();
                }
                else if (e.questionText.ToLower().Contains("surface"))
                {
                    // Calcul de la surface
                    double surface = rectangle.Multiplication(longueur,largeur);  // Surface = longueur × largeur
                    surface = Math.Round(surface);  // Arrondir le résultat à l'entier le plus proche
                    detailedCalculation = $"Surface = longueur × largeur = {longueur} × {largeur} = {surface}";
                    e.correctAnswer = surface.ToString();
                }
                else
                {
                    detailedCalculation = "Formule non reconnue.";
                }

                recapitulatif.Add((
                    $"[Rectangle] {e.questionText}",
                    e.userAnswer,
                    e.correctAnswer,
                    detailedCalculation
                ));
            }

            NavigateToRandomPage();
        }

        private void TrianglePage_OnVerificationCompleted(object sender, (bool isCorrect, string userAnswer, string correctAnswer, string questionText) e)
        {
            if (e.isCorrect) bonnesReponses++;

            if (sender is TriangleExamPage trianglePage)
            {
                // Récupérer les valeurs depuis la page TriangleExamPage
                int coteA = int.Parse(trianglePage.TxtCoteA.Text);
                int coteB = int.Parse(trianglePage.TxtCoteB.Text);
                int baseTri = int.Parse(trianglePage.TxtBase.Text);
                int hauteur = int.Parse(trianglePage.TxtHauteur.Text);

                string detailedCalculation;

                if (e.questionText.ToLower().Contains("surface"))
                {
                    // Calcul de la surface
                    double surface = triangle.Multiplication(triangle.Multiplication(baseTri,hauteur),0.5);  // Surface = (base × hauteur) ÷ 2
                    surface = Math.Round(surface);  // Arrondir le résultat à l'entier le plus proche
                    detailedCalculation = $"Surface = (base × hauteur) ÷ 2 = ({baseTri} × {hauteur}) ÷ 2 = {surface}";
                    e.correctAnswer = surface.ToString();
                }
                else if (e.questionText.ToLower().Contains("périmètre"))
                {
                    // Calcul du périmètre
                    double perimetre = triangle.Addition(triangle.Addition(coteA,coteB),baseTri);  // Périmètre = côtéA + côtéB + base
                    perimetre = Math.Round(perimetre);  // Arrondir le résultat à l'entier le plus proche
                    detailedCalculation = $"Périmètre = côtéA + côtéB + base = {coteA} + {coteB} + {baseTri} = {perimetre}";
                    e.correctAnswer = perimetre.ToString();
                }
                else
                {
                    detailedCalculation = "Formule non reconnue.";
                }

                recapitulatif.Add((
                    $"[Triangle] {e.questionText}",
                    e.userAnswer,
                    e.correctAnswer,
                    detailedCalculation
                ));
            }

            NavigateToRandomPage();
        }

        private void CerclePage_OnVerificationCompleted(object sender, (bool isCorrect, string userAnswer, string correctAnswer, string questionText) e)
        {
            if (e.isCorrect) bonnesReponses++;

            if (sender is CercleExamPage cerclePage)
            {
                // Récupérer la valeur du rayon
                int rayon = int.Parse(cerclePage.txtRayon.Text);
                string detailedCalculation;

                if (e.questionText.ToLower().Contains("surface"))
                {
                    // Calcul de la surface avec Pi approximé par Math.PI
                    double surface = cercle.Multiplication(cercle.Multiplication(Math.PI,rayon),rayon);  // Surface = π × rayon²
                    surface = Math.Round(surface);  // Arrondir le résultat à l'entier le plus proche
                    detailedCalculation = $"Surface = π × rayon × rayon = π × {rayon} × {rayon} ≈ {surface}";
                    e.correctAnswer = surface.ToString();
                }
                else if (e.questionText.ToLower().Contains("périmètre") || e.questionText.ToLower().Contains("circonférence"))
                {
                    // Calcul du périmètre avec Math.PI
                    double perimetre = cercle.Multiplication(cercle.Multiplication(2,Math.PI),rayon);  // Périmètre = 2 × π × rayon
                    perimetre = Math.Round(perimetre);  // Arrondir le résultat à l'entier le plus proche
                    detailedCalculation = $"Périmètre = 2 × π × rayon = 2 × π × {rayon} ≈ {perimetre}";
                    e.correctAnswer = perimetre.ToString();
                }
                else
                {
                    detailedCalculation = "Formule non reconnue.";
                }

                recapitulatif.Add((
                    $"[Cercle] {e.questionText}",
                    e.userAnswer,
                    e.correctAnswer,
                    detailedCalculation
                ));
            }

            NavigateToRandomPage();
        }
    }
}
