﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Geometrie
{
    public partial class RecapitulatifPage : Page
    {
        private List<(string questionText, string userAnswer, string correctAnswer, string detailedCalculation)> recapData;
        private int bonnesReponses;
        private ClasseCalcul calcul = new ClasseCalcul();

        public RecapitulatifPage(List<(string questionText, string userAnswer, string correctAnswer, string detailedCalculation)> recapData, int bonnesReponses = 0)
        {
            InitializeComponent();
            this.recapData = recapData;
            this.bonnesReponses = bonnesReponses;

            // On utilise une instance de la classe Calcul pour les calculs
            foreach (var item in recapData)
            {
                Border card = new Border
                {
                    Background = Brushes.White,
                    CornerRadius = new CornerRadius(15),
                    Margin = new Thickness(10),
                    Padding = new Thickness(15),
                    BorderBrush = Brushes.LightGray,
                    BorderThickness = new Thickness(1)
                };

                StackPanel cardContent = new StackPanel { Orientation = Orientation.Vertical };

                // Question
                cardContent.Children.Add(new TextBlock
                {
                    Text = $"Q: {item.questionText}",
                    FontSize = 18,
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.DarkSlateGray
                });

                // Réponse donnée
                cardContent.Children.Add(new TextBlock
                {
                    Text = $"Réponse donnée : {item.userAnswer}",
                    FontSize = 16,
                    Foreground = Brushes.Crimson
                });

                // Réponse correcte
                cardContent.Children.Add(new TextBlock
                {
                    Text = $"Réponse correcte : {item.correctAnswer}",
                    FontSize = 16,
                    Foreground = Brushes.ForestGreen
                });

                // Détail du calcul
                string detailedCalculation = item.detailedCalculation;
                if (detailedCalculation.Contains("x"))
                {
                    // On fait un calcul si la question implique une multiplication aléatoire
                    int randomValue = calcul.Init();
                    detailedCalculation += $" => Exemple de calcul avec valeur aléatoire : {randomValue}";
                }

                cardContent.Children.Add(new TextBlock
                {
                    Text = $"Détail du calcul : {detailedCalculation}",
                    FontSize = 14,
                    Foreground = Brushes.SteelBlue,
                    TextWrapping = TextWrapping.Wrap
                });

                card.Child = cardContent;
                RecapitulatifPanel.Children.Add(card);
            }
        }

        private void BtnAccueil_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Window.GetWindow(this)?.Close();
        }

        private void BtnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ResultatPage(bonnesReponses, recapData));
        }
    }
}
