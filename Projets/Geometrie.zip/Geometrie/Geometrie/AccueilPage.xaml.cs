﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace Geometrie
{
    public partial class AccueilPage : Page
    {
        public AccueilPage()
        {
            InitializeComponent();
        }

        private void BtnCarre_Click(object sender, RoutedEventArgs e)
        {
            NavigationFrame.Navigate(new CarrePage());
        }

        private void BtnRectangle_Click(object sender, RoutedEventArgs e)
        {
            NavigationFrame.Navigate(new RectanglePage());
        }

        private void BtnTriangle_Click(object sender, RoutedEventArgs e)
        {
            NavigationFrame.Navigate(new TrianglePage());
        }

        private void BtnCercle_Click(object sender, RoutedEventArgs e)
        {
            NavigationFrame.Navigate(new CerclePage());
        }

        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Window.GetWindow(this)?.Close();
        }

        private void BtnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void NavigationFrame_Navigated(object sender, NavigationEventArgs e)
        {
            // Éventuellement utilisé pour gérer l’historique ou activer des boutons
        }
    }
}
