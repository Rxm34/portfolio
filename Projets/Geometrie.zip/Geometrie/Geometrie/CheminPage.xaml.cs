﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Geometrie
{
    /// <summary>
    /// Logique d'interaction pour CheminPage.xaml
    /// </summary>
    public partial class CheminPage : Page
    {
        public CheminPage()
        {
            InitializeComponent();
        }

        private void BtnValider_Click(object sender, RoutedEventArgs e)
        {

        }

        private void VerifierButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void RetourButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void QuitterButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void LancerDeButton_Click(object sender, RoutedEventArgs e)
        {
            Random rand = new Random();
            int resultat = rand.Next(1, 7); // entre 1 et 6

            // Assurez-vous que les images "de1.jpg", ..., "de6.jpg" sont dans le dossier du projet (BuildAction = Resource)
            string cheminImage = $"{resultat}de.jpg";
            ImageDe.Source = new BitmapImage(new Uri(cheminImage, UriKind.Relative));
        }

    }
}
