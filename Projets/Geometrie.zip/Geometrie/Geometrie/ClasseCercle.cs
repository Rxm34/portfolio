﻿using System;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Windows;

namespace Geometrie
{
    public class ClasseCercle : ClasseRond
    {
        // Appel de l'initialisation de la classe parente (ClasseRond)
        public new void Init()
        {
            base.Init(); // Appelle la méthode Init de la classe de base
        }

        // Calcul du périmètre sans effectuer de calcul direct dans cette classe
        public double Perimetre()
        {
            double rayonDouble = Convert.ToDouble(UneValeur);
            // Utilisation de la méthode de multiplication dans ClasseRond pour éviter les calculs directs
            double resultatPerimetre = Multiplication(Multiplication(rayonDouble, 2), Math.PI);
            return Math.Round(resultatPerimetre, 2); // Retourne le périmètre avec 2 décimales
        }

        // Calcul de la surface sans effectuer de calcul direct dans cette classe
        public double Surface()
        {
            double rayonDouble = Convert.ToDouble(UneValeur);
            // Utilisation de la méthode de multiplication dans ClasseRond pour éviter les calculs directs
            double resultatSurface = Multiplication(Multiplication(rayonDouble, rayonDouble), Math.PI);
            return Math.Round(resultatSurface, 2); // Retourne la surface avec 2 décimales
        }

        // Méthode de dessin du cercle sur un Canvas
        public void Dessin(Canvas drawingCanvas, TextBox txtRayon)
        {
            try
            {
                // Convertir le rayon en entier (cm)
                double rayonCm = Convert.ToInt32(txtRayon.Text); // Rayon en cm
                int rayonPixels = Convert.ToInt32(Multiplication(rayonCm, 20)); // Conversion de cm en pixels (1 cm = 20 pixels)

                // Création du cercle (Ellipse) à dessiner sur le Canvas
                Ellipse cercle = new Ellipse
                {
                    Width = Multiplication(rayonPixels, 2),  // Largeur = 2 fois le rayon en pixels
                    Height = Multiplication(rayonPixels, 2), // Hauteur = 2 fois le rayon en pixels
                    Stroke = System.Windows.Media.Brushes.Black, // Contour noir
                    StrokeThickness = 2,      // Épaisseur du contour
                    Fill = System.Windows.Media.Brushes.Transparent // Remplissage transparent
                };

                // Utilisation des méthodes de la classe de calcul pour les positions
                double widthDifference = Soustraction(drawingCanvas.ActualWidth, cercle.Width);  // Calcul de la différence de largeur
                double centerX = Division(widthDifference, 2); // Division pour centrer horizontalement
                centerX = Soustraction(centerX, 50); // Décalage horizontal de -50

                double heightDifference = Soustraction(drawingCanvas.ActualHeight, cercle.Height); // Calcul de la différence de hauteur
                double centerY = Division(heightDifference, 2); // Division pour centrer verticalement
                centerY = Soustraction(centerY, 50); // Décalage vertical de -50

                // Positionner le cercle sur le Canvas
                Canvas.SetLeft(cercle, centerX);
                Canvas.SetTop(cercle, centerY);

                // Nettoyer le Canvas et ajouter le cercle
                drawingCanvas.Children.Clear();
                drawingCanvas.Children.Add(cercle);
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez entrer un rayon valide en cm.");
            }
        }

    }
}
