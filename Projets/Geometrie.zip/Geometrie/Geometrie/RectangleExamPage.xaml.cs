﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace Geometrie
{
    public partial class RectangleExamPage : Page
    {
        public event EventHandler<(bool isCorrect, string userAnswer, string correctAnswer, string questionText)> OnVerificationCompleted;
        private DispatcherTimer timer;
        private ClasseRectangle rectangle = new ClasseRectangle();
        private ClasseCalcul calcul = new ClasseCalcul();  // Utilisation de ClasseCalcul
        private bool estPerimetreVisible;

        public RectangleExamPage()
        {
            InitializeComponent();
            rectangle.Init();
            TxtLongueur.Text = rectangle.UneValeur.ToString();
            TxtLargeur.Text = rectangle.Largeur.ToString();

            Random random = new Random();
            int cacherPerimetre = random.Next(2);
            estPerimetreVisible = cacherPerimetre == 1;

            if (!estPerimetreVisible)
            {
                TxtPerimetre.Visibility = Visibility.Collapsed;
                BtnVerifierPerimetre.Visibility = Visibility.Collapsed;
                TxtPerimetreReponse.Visibility = Visibility.Collapsed;
                LblPerimetre.Visibility = Visibility.Collapsed;
            }
            else
            {
                TxtSurface.Visibility = Visibility.Collapsed;
                BtnVerifierSurface.Visibility = Visibility.Collapsed;
                TxtSurfaceReponse.Visibility = Visibility.Collapsed;
                LblSurface.Visibility = Visibility.Collapsed;
            }

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(5);
            timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            OnVerificationCompleted?.Invoke(this, (
                false,
                "Aucune réponse",
                "?",
                "Temps écoulé"
            ));
        }

        private void DrawingCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            rectangle.Dessin(DrawingCanvas,TxtLongueur,TxtLargeur);
        }

        private void BtnVerifierPerimetre_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int longueur = Convert.ToInt32(TxtLongueur.Text);
                int largeur = Convert.ToInt32(TxtLargeur.Text);
                rectangle.UneValeur = longueur;
                rectangle.Largeur = largeur;

                int perimetreCorrect = Convert.ToInt32(rectangle.Perimetre());
                int perimetreUtilisateur = Convert.ToInt32(TxtPerimetre.Text);

                bool isCorrect = perimetreCorrect == perimetreUtilisateur;
                TxtPerimetreReponse.Text = isCorrect ? "Bonne réponse !" : "Mauvaise réponse !";
                TxtPerimetreReponse.Foreground = isCorrect ? Brushes.Green : Brushes.Red;
                TxtPerimetreReponse.Visibility = Visibility.Visible;

                // Calcul de la réponse avec la classe Calcul
                OnVerificationCompleted?.Invoke(this, (
                    isCorrect,
                    perimetreUtilisateur.ToString(),
                    perimetreCorrect.ToString(),
                    $"Périmètre d’un rectangle de longueur {longueur} et de largeur {largeur}"
                ));
            }
            catch (FormatException)
            {
                MessageBox.Show("Pas de nombres à virgules et pas de lettres.");
            }
        }

        private void BtnVerifierSurface_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int longueur = Convert.ToInt32(TxtLongueur.Text);
                int largeur = Convert.ToInt32(TxtLargeur.Text);
                rectangle.UneValeur = longueur;
                rectangle.Largeur = largeur;

                double surfaceCorrecte = rectangle.Surface();
                int surfaceArrondie = Convert.ToInt32(Math.Round(surfaceCorrecte));
                int surfaceUtilisateur = Convert.ToInt32(TxtSurface.Text);

                bool isCorrect = surfaceArrondie == surfaceUtilisateur;
                TxtSurfaceReponse.Text = isCorrect ? "Bonne réponse !" : "Mauvaise réponse !";
                TxtSurfaceReponse.Foreground = isCorrect ? Brushes.Green : Brushes.Red;
                TxtSurfaceReponse.Visibility = Visibility.Visible;

                // Calcul de la réponse avec la classe Calcul
                OnVerificationCompleted?.Invoke(this, (
                    isCorrect,
                    surfaceUtilisateur.ToString(),
                    surfaceArrondie.ToString(),
                    $"Surface d’un rectangle de longueur {longueur} et une largeur de {largeur}"
                ));
            }
            catch (FormatException)
            {
                MessageBox.Show("Pas de nombres à virgules et pas de lettres.");
            }
        }
    }
}
