﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Geometrie
{
    /// <summary>
    /// Logique d'interaction pour TrianglePage.xaml
    /// </summary>
    public partial class TrianglePage : Page
    {
        ClasseTriangle triangle = new ClasseTriangle();

        public TrianglePage()
        {
            InitializeComponent();
            triangle.Init();
            TxtCoteA.Text = triangle.C1.ToString();
            TxtCoteB.Text = triangle.C2.ToString();
            TxtBase.Text = triangle.BaseRecalculee.ToString();  // Affichage de la base recalculée
            TxtHauteur.Text = triangle.Haut.ToString();
            triangle.Dessin(DrawingCanvas, TxtCoteA, TxtCoteB, TxtBase);
        }

        private void BtnChangerTriangle_Click(object sender, RoutedEventArgs e)
        {
            // Générer un nouveau triangle
            triangle.Init();

            // Mettre à jour tous les champs
            TxtCoteA.Text = triangle.C1.ToString();
            TxtCoteB.Text = triangle.C2.ToString();
            TxtHauteur.Text = triangle.Haut.ToString();

            // Redessiner le triangle et afficher la base recalculée
            triangle.Dessin(DrawingCanvas, TxtCoteA, TxtCoteB, TxtBase);
            TxtBase.Text = triangle.BaseRecalculee.ToString();

            // Effacer les anciens calculs
            TxtPerimetre.Clear();
            TxtSurface.Clear();
            TxtPerimetreReponse.Visibility = Visibility.Hidden;
            TxtSurfaceReponse.Visibility = Visibility.Hidden;
        }

        private void BtnVerifierPerimetre_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Recalculer le périmètre à partir des valeurs actuelles
                int perimetreCorrect = Convert.ToInt32(triangle.Perimetre());

                if (int.TryParse(TxtPerimetre.Text, out int perimetreUtilisateur))
                {
                    if (perimetreCorrect == perimetreUtilisateur)
                    {
                        TxtPerimetreReponse.Text = "Bonne réponse !";
                        TxtPerimetreReponse.Foreground = Brushes.Green;
                    }
                    else
                    {
                        TxtPerimetreReponse.Text = "Mauvaise réponse !";
                        TxtPerimetreReponse.Foreground = Brushes.Red;
                    }

                    TxtPerimetreReponse.Visibility = Visibility.Visible;
                }
                else
                {
                    MessageBox.Show("Veuillez entrer un périmètre valide (entier).");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez entrer un périmètre valide.");
            }
        }

        private void BtnVerifierSurface_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Calculer la surface correcte avec un entier
                int surfaceCorrecte = triangle.Surface();

                // Vérifier si la valeur entrée est un entier
                if (int.TryParse(TxtSurface.Text, out int surfaceUtilisateur))
                {
                    if (surfaceCorrecte == surfaceUtilisateur)
                    {
                        TxtSurfaceReponse.Text = "Bonne réponse !";
                        TxtSurfaceReponse.Foreground = Brushes.Green;
                    }
                    else
                    {
                        TxtSurfaceReponse.Text = "Mauvaise réponse !";
                        TxtSurfaceReponse.Foreground = Brushes.Red;
                    }

                    TxtSurfaceReponse.Visibility = Visibility.Visible;
                }
                else
                {
                    MessageBox.Show("Veuillez entrer une surface valide (entier).");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez entrer une surface valide.");
            }
        }

        private void BtnIndicePerimetre_Click(object sender, RoutedEventArgs e)
        {
            TxtPerimetre.Text = "Côté A + Côté B + Base";
        }

        private void BtnIndiceSurface_Click(object sender, RoutedEventArgs e)
        {
            TxtSurface.Text = "(Base × Hauteur) ÷ 2";
        }

        private void TxtPerimetre_GotFocus(object sender, RoutedEventArgs e)
        {
            if (TxtPerimetre.Text == "Côté A + Côté B + Base")
            {
                TxtPerimetre.Clear();
            }
        }

        private void TxtSurface_GotFocus(object sender, RoutedEventArgs e)
        {
            if (TxtSurface.Text == "(Base × Hauteur) ÷ 2")
            {
                TxtSurface.Clear();
            }
        }


        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.NavigationFrame.Navigate(new AccueilPage());
        }

        private void BtnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void NavigationFrame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {

        }
    }
}
