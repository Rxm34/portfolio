﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Geometrie
{
    /// <summary>
    /// Logique d'interaction pour CerclePage.xaml
    /// </summary>
    public partial class CerclePage : Page
    {
        ClasseCercle cercle = new ClasseCercle();

        public CerclePage()
        {
            InitializeComponent();
            cercle.Init();
            txtRayon.Text = cercle.UneValeur.ToString();
        }

        private void DrawingCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            cercle.Init();
            txtRayon.Text = cercle.UneValeur.ToString();
            cercle.Dessin(DrawingCanvas, txtRayon);
        }

        private void btnVerifierPerimetre_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int rayon = Convert.ToInt32(txtRayon.Text);
                cercle.UneValeur = rayon;

                double perimetreCorrect = cercle.Perimetre();
                int perimetreArrondie = Convert.ToInt32(Math.Round(perimetreCorrect)); 
                int perimetreUtilisateur = Convert.ToInt32(txtPerimetre.Text);

                if (perimetreArrondie == perimetreUtilisateur) 
                {
                    txtBlockResultatPerimetre.Text = "Bonne réponse !";
                    txtBlockResultatPerimetre.Foreground = Brushes.Green;
                }
                else
                {
                    txtBlockResultatPerimetre.Text = "Mauvaise réponse !"; 
                    txtBlockResultatPerimetre.Foreground = Brushes.Red;
                }
                txtBlockResultatPerimetre.Visibility = Visibility.Visible;
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez entrer un rayon ou un périmètre valide.");
            }
        }


        private void BtnVerifierSurface_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int rayon = Convert.ToInt32(txtRayon.Text);
                cercle.UneValeur = rayon;

                double surfaceCorrecte = cercle.Surface();
                int surfaceArrondie = Convert.ToInt32(Math.Round(surfaceCorrecte));
                int surfaceUtilisateur = Convert.ToInt32(txtSurface.Text);

                if (surfaceArrondie == surfaceUtilisateur)
                {
                    txtBlockResultatSurface.Text = "Bonne réponse !";
                    txtBlockResultatSurface.Foreground = Brushes.Green;
                }
                else
                {
                    txtBlockResultatSurface.Text = "Mauvaise réponse !";
                    txtBlockResultatSurface.Foreground = Brushes.Red;
                }
                txtBlockResultatSurface.Visibility = Visibility.Visible;
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez entrer un rayon ou une surface valide.");
            }
        }

        private void btnChangerRayon_Click(object sender, RoutedEventArgs e)
        {
            txtPerimetre.Clear();
            txtSurface.Clear();
            txtBlockResultatPerimetre.Visibility = Visibility.Hidden;
            txtBlockResultatSurface.Visibility = Visibility.Hidden;
            cercle.Init();
            txtRayon.Text = cercle.UneValeur.ToString();
            cercle.Dessin(DrawingCanvas, txtRayon);
        }
        private void btnIndicePerimetre_Click(object sender, RoutedEventArgs e)
        {
            txtPerimetre.Text = "2 × π × Rayon";
        }

        private void btnIndiceSurface_Click(object sender, RoutedEventArgs e)
        {
            txtSurface.Text = "π × Rayon × Rayon";
        }

        private void txtPerimetre_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtPerimetre.Text == "2 × π × Rayon")
            {
                txtPerimetre.Clear();
            }
        }

        private void txtSurface_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtSurface.Text == "π × Rayon × Rayon")
            {
                txtSurface.Clear();
            }
        }


        private void btnRetour_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.NavigationFrame.Navigate(new AccueilPage());

        }

        private void btnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
