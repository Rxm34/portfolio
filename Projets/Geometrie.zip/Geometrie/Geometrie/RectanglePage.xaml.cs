﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Geometrie
{
    /// <summary>
    /// Logique d'interaction pour RectanglePage.xaml
    /// </summary>
    public partial class RectanglePage : Page
    {
        ClasseRectangle rectangle = new ClasseRectangle();
        public RectanglePage()
        {
            InitializeComponent();
            rectangle.Init();
            TxtLongueur.Text = rectangle.UneValeur.ToString();
            TxtLargeur.Text = rectangle.Largeur.ToString();
        }


        private void DrawingCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            rectangle.Init();
            TxtLongueur.Text = rectangle.UneValeur.ToString();
            TxtLargeur.Text = rectangle.Largeur.ToString();
            rectangle.Dessin(DrawingCanvas, TxtLongueur, TxtLargeur);
        }

        private void BtnChangerRectangle_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Lire les valeurs de longueur et largeur
                int longueur = Convert.ToInt32(TxtLongueur.Text);
                int largeur = Convert.ToInt32(TxtLargeur.Text);

                // Réinitialiser le rectangle si les valeurs sont différentes
                do
                {
                    rectangle.Init();
                }
                while (rectangle.UneValeur == longueur || rectangle.Largeur == largeur); // S'assurer que les valeurs sont différentes

                // Vider les zones de réponse
                TxtPerimetre.Clear();
                TxtSurface.Clear();
                TxtPerimetreReponse.Visibility = Visibility.Hidden;
                TxtSurfaceReponse.Visibility = Visibility.Hidden;

                // Mettre à jour les dimensions
                TxtLongueur.Text = rectangle.UneValeur.ToString();
                TxtLargeur.Text = rectangle.Largeur.ToString();

                // Dessiner le rectangle avec les nouvelles dimensions
                rectangle.Dessin(DrawingCanvas, TxtLongueur, TxtLargeur);
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez entrer des valeurs valides pour la longueur et la largeur.");
            }
        }
        private void BtnIndicePerimetre_Click(object sender, RoutedEventArgs e)
        {
            TxtPerimetre.Text = "2 × (Longueur + Largeur)"; // Affiche l'indice pour le périmètre
        }

        private void BtnIndiceSurface_Click(object sender, RoutedEventArgs e)
        {
            TxtSurface.Text = "Longueur × Largeur"; // Affiche l'indice pour la surface
        }

        private void TxtPerimetre_GotFocus(object sender, RoutedEventArgs e)
        {
            // Efface le texte de la TextBox lorsque l'utilisateur clique dedans si elle contient l'indice
            if (TxtPerimetre.Text == "2 × (Longueur + Largeur)")
            {
                TxtPerimetre.Clear();
            }
        }

        private void TxtSurface_GotFocus(object sender, RoutedEventArgs e)
        {
            // Efface le texte de la TextBox lorsque l'utilisateur clique dedans si elle contient l'indice
            if (TxtSurface.Text == "Longueur × Largeur")
            {
                TxtSurface.Clear();
            }
        }


        private void BtnVerifierPerimetre_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int perimetreCorrect = Convert.ToInt16(rectangle.Perimetre());
                int perimetreUtilisateur = Convert.ToInt32(TxtPerimetre.Text);

                if (perimetreCorrect == perimetreUtilisateur)
                {
                    TxtPerimetreReponse.Text = "Bonne réponse !";
                    TxtPerimetreReponse.Foreground = Brushes.Green;
                }
                else
                {
                    TxtPerimetreReponse.Text = "Mauvaise réponse !";
                    TxtPerimetreReponse.Foreground = Brushes.Red;
                }

                TxtPerimetreReponse.Visibility = Visibility.Visible;
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez entrer un périmètre valide.");
            }
        }

        private void BtnVerifierSurface_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double surfaceCorrecte = rectangle.Surface();
                int surfaceArrondie = Convert.ToInt32(Math.Round(surfaceCorrecte));
                int surfaceUtilisateur = Convert.ToInt32(TxtSurface.Text);

                if (surfaceArrondie == surfaceUtilisateur)
                {
                    TxtSurfaceReponse.Text = "Bonne réponse !";
                    TxtSurfaceReponse.Foreground = Brushes.Green;
                }
                else
                {
                    TxtSurfaceReponse.Text = "Mauvaise réponse !";
                    TxtSurfaceReponse.Foreground = Brushes.Red;
                }

                TxtSurfaceReponse.Visibility = Visibility.Visible;
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez entrer une surface valide.");
            }
        }

        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.NavigationFrame.Navigate(new AccueilPage());
        }

        private void BtnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
