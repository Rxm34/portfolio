﻿using System;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Windows;

namespace Geometrie
{
    public class ClasseRectangle : Classe4Angles
    {
        public int Largeur;

        private ClasseCalcul calcul = new ClasseCalcul(); // Instance dédiée pour la largeur

        public new void Init()
        {
            base.Init(); // Initialise UneValeur (longueur)

            do
            {
                Largeur = calcul.Init(); // Initialise Largeur via ClasseCalcul
            }
            while (Largeur == UneValeur); // Évite que Largeur soit égale à UneValeur
        }

        public double Perimetre()
        {
            return base.Addition(base.Multiplication(Largeur, 2), base.Multiplication(UneValeur, 2));
        }

        public double Surface()
        {
            return base.Multiplication(Largeur, UneValeur);
        }

        public void Dessin(Canvas drawingCanvas, TextBox TxtLongueur, TextBox TxtLargeur)
        {
            try
            {
                int longueur = Convert.ToInt32(TxtLongueur.Text);
                int largeur = Convert.ToInt32(TxtLargeur.Text);

                Rectangle rect = new Rectangle
                {
                    Width = longueur * 20,
                    Height = largeur * 20,
                    Stroke = System.Windows.Media.Brushes.Black,
                    StrokeThickness = 2,
                    Fill = System.Windows.Media.Brushes.Transparent
                };

                double centerX = (drawingCanvas.ActualWidth - rect.Width) / 2;
                double centerY = (drawingCanvas.ActualHeight - rect.Height) / 2;

                Canvas.SetLeft(rect, centerX);
                Canvas.SetTop(rect, centerY);

                drawingCanvas.Children.Clear();
                drawingCanvas.Children.Add(rect);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du dessin du rectangle: {ex.Message}");
            }
        }
    }
}
