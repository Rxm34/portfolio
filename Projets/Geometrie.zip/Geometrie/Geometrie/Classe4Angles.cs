﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometrie
{
    public abstract class Classe4Angles : ClasseAvecAngle
    {
    }
}
