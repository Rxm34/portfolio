﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Geometrie
{
    public class ClasseTriangle : ClasseAvecAngle
    {
        public int C1;
        public int C2;
        public int Haut;
        public int BaseRecalculee;


        public new void Init()
        {
            base.Init();
            C1 = base.Init();
            C2 = base.Init();
            Haut = base.Init();
            BaseRecalculee = 0;
        }

        public double Perimetre()
        {
            return Addition(Addition(C1, C2), BaseRecalculee);
        }

        public int Surface()
        {
            double surface = Multiplication(Multiplication(BaseRecalculee, Haut), 0.5);
            return (int)Math.Round(surface, MidpointRounding.AwayFromZero);
        }

        public void Dessin(Canvas DrawingCanvas, TextBox TxtCoteA, TextBox TxtCoteB, TextBox TxtBase)
        {
            DrawingCanvas.Children.Clear();

            const double echelle = 30.0;

            if (double.TryParse(TxtCoteA.Text, out double coteA) && double.TryParse(TxtCoteB.Text, out double coteB))
            {
                double coteAPx = Multiplication(coteA, echelle);
                double coteBPx = Multiplication(coteB, echelle);

                double pointAX = 0;
                double pointAY = 250;

                double pointBX = Addition(pointAX, coteAPx);
                double pointBY = pointAY;

                double angle = Division(Math.PI,3);
                double cosAngle = Math.Cos(angle);
                double sinAngle = Math.Sin(angle);

                double pointCX = Addition(pointAX, Multiplication(coteBPx, cosAngle));
                double pointCY = Addition(pointAY, Multiplication(-1, Multiplication(coteBPx, sinAngle)));

                double deltaX = Soustraction(pointBX, pointCX);
                double deltaY = Soustraction(pointBY, pointCY);
                double basePx = Math.Sqrt(Addition(Multiplication(deltaX, deltaX), Multiplication(deltaY, deltaY)));

                BaseRecalculee = (int)Math.Round(Division(basePx, echelle), MidpointRounding.AwayFromZero);
                TxtBase.Text = BaseRecalculee.ToString();

                Point pointA = new Point(pointAX, pointAY);
                Point pointB = new Point(pointBX, pointBY);
                Point pointC = new Point(pointCX, pointCY);

                DrawLine(DrawingCanvas, pointA, pointB);
                DrawLine(DrawingCanvas, pointA, pointC);
                DrawLine(DrawingCanvas, pointB, pointC);
            }
            else
            {
                MessageBox.Show("Veuillez entrer des longueurs valides pour les côtés A et B.");
            }
        }

        private void DrawLine(Canvas canvas, Point p1, Point p2)
        {
            canvas.Children.Add(new Line
            {
                X1 = p1.X,
                Y1 = p1.Y,
                X2 = p2.X,
                Y2 = p2.Y,
                Stroke = Brushes.Black,
                StrokeThickness = 2
            });
        }
    }
}
