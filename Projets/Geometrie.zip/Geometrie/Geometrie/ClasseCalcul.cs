﻿using System;

namespace Geometrie
{
    public class ClasseCalcul
    {
        public int UneValeur;

        Random NbRandom = new Random();

        public int Init()
        {
            UneValeur = NbRandom.Next(1, 10);
            return UneValeur;
        }

        public double Addition(double valeur1, double valeur2)
        {
            return valeur1 + valeur2;
        }
        public double Soustraction(double valeur1, double valeur2)
        {
            return valeur1 - valeur2;
        }

        public double Multiplication(double valeur1, double valeur2)
        {
            return valeur1 * valeur2;
        }
        public double Division(double valeur1, double valeur2)
        {
            return valeur1 / valeur2;
        }
    }
}
