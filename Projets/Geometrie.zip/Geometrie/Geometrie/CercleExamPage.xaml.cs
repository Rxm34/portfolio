﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace Geometrie
{
    public partial class CercleExamPage : Page
    {
        public event EventHandler<(bool isCorrect, string userAnswer, string correctAnswer, string questionText)> OnVerificationCompleted;
        private DispatcherTimer timer;
        private ClasseCercle cercle = new ClasseCercle();
        private ClasseCalcul calcul = new ClasseCalcul();  // Utilisation de ClasseCalcul
        private bool estPerimetreVisible;

        public CercleExamPage()
        {
            InitializeComponent();
            cercle.Init();
            txtRayon.Text = cercle.UneValeur.ToString();
            cercle.Dessin(DrawingCanvas, txtRayon);

            Random random = new Random();
            int cacherPerimetre = random.Next(2);
            estPerimetreVisible = cacherPerimetre == 1;

            if (!estPerimetreVisible)
            {
                TxtPerimetre.Visibility = Visibility.Collapsed;
                BtnVerifierPerimetre.Visibility = Visibility.Collapsed;
                TxtPerimetreReponse.Visibility = Visibility.Collapsed;
                LblPerimetre.Visibility = Visibility.Collapsed;
            }
            else
            {
                TxtSurface.Visibility = Visibility.Collapsed;
                BtnVerifierSurface.Visibility = Visibility.Collapsed;
                TxtSurfaceReponse.Visibility = Visibility.Collapsed;
                LblSurface.Visibility = Visibility.Collapsed;
            }

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(5);
            timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            OnVerificationCompleted?.Invoke(this, (
                false,
                "Aucune réponse",
                "?",
                "Temps écoulé"
            ));
        }

        private void DrawingCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            cercle.Dessin(DrawingCanvas, txtRayon);
        }

        private void BtnVerifierPerimetre_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int rayon = Convert.ToInt32(txtRayon.Text);
                cercle.UneValeur = rayon;

                double perimetreCorrect = cercle.Perimetre();
                int perimetreArrondi = Convert.ToInt32(Math.Round(perimetreCorrect));
                int perimetreUtilisateur = Convert.ToInt32(TxtPerimetre.Text);

                bool isCorrect = perimetreArrondi == perimetreUtilisateur;
                TxtPerimetreReponse.Text = isCorrect ? "Bonne réponse !" : "Mauvaise réponse !";
                TxtPerimetreReponse.Foreground = isCorrect ? Brushes.Green : Brushes.Red;
                TxtPerimetreReponse.Visibility = Visibility.Visible;

                // Calcul de la réponse avec la classe Calcul
                OnVerificationCompleted?.Invoke(this, (
                    isCorrect,
                    perimetreUtilisateur.ToString(),
                    perimetreArrondi.ToString(),
                    $"Périmètre d’un cercle de rayon {rayon}"
                ));
            }
            catch (FormatException)
            {
                MessageBox.Show("Pas de nombres à virgules et pas de lettres.");
            }
        }

        private void BtnVerifierSurface_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int rayon = Convert.ToInt32(txtRayon.Text);
                cercle.UneValeur = rayon;

                double surfaceCorrecte = cercle.Surface();
                int surfaceArrondie = Convert.ToInt32(Math.Round(surfaceCorrecte));
                int surfaceUtilisateur = Convert.ToInt32(TxtSurface.Text);

                bool isCorrect = surfaceArrondie == surfaceUtilisateur;
                TxtSurfaceReponse.Text = isCorrect ? "Bonne réponse !" : "Mauvaise réponse !";
                TxtSurfaceReponse.Foreground = isCorrect ? Brushes.Green : Brushes.Red;
                TxtSurfaceReponse.Visibility = Visibility.Visible;

                // Calcul de la réponse avec la classe Calcul
                OnVerificationCompleted?.Invoke(this, (
                    isCorrect,
                    surfaceUtilisateur.ToString(),
                    surfaceArrondie.ToString(),
                    $"Surface d’un cercle de rayon {rayon}"
                ));
            }
            catch (FormatException)
            {
                MessageBox.Show("Pas de nombres à virgules et pas de lettres.");
            }
        }
    }
}
