﻿using System;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows;

namespace Geometrie
{
    public class ClasseCarre : Classe4Angles
    {
        // On suppose que la classe ClasseCalcul est déjà instanciée ailleurs, donc pas besoin de l'instancier ici.

        public new void Init()
        {
            base.Init(); // Initialisation de la classe de base (héritée de Classe4Angles)
        }

        public double Perimetre()
        {
            // Utilisation de la méthode de multiplication de ClasseCalcul (pas de calcul direct ici)
            return Multiplication(4, UneValeur);
        }

        public double Surface()
        {
            // Utilisation de la méthode de multiplication pour obtenir la surface du carré
            return Multiplication(UneValeur, UneValeur);
        }

        public void Dessin(Canvas drawingCanvas, TextBox txtCote)
        {
            // Vérifier si le TextBox contient une valeur valide pour le côté
            if (int.TryParse(txtCote.Text, out int coteEnCm))
            {
                // Conversion du côté en cm en pixels (en supposant un DPI de 96)
                double dpi = 96;  // DPI standard de l'écran
                double coteEnPixels = Multiplication(Division(dpi,2.54),coteEnCm); // Conversion de cm en pixels

                // Créer un nouveau Rectangle pour dessiner le carré
                Rectangle carre = new Rectangle
                {
                    Width = coteEnPixels,  // La largeur du carré (en pixels)
                    Height = coteEnPixels, // La hauteur du carré (en pixels)
                    Stroke = Brushes.Black, // Couleur du bord du carré
                    Fill = Brushes.Transparent, // Remplir le carré avec une couleur transparente
                    StrokeThickness = 2 // Épaisseur du bord
                };

                // Ajouter le rectangle au Canvas
                drawingCanvas.Children.Clear(); // Effacer les dessins précédents
                drawingCanvas.Children.Add(carre); // Ajouter le nouveau carré

                // Positionner le carré au centre du Canvas
                Canvas.SetLeft(carre, Division(Soustraction(drawingCanvas.Width, carre.Width), 2));
                Canvas.SetTop(carre, Division(Soustraction(drawingCanvas.Height, carre.Height), 2));
            }
            else
            {
                MessageBox.Show("Veuillez entrer une valeur valide pour le côté en cm.");
            }
        }
    }
}
