﻿using Geometrie;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Navigation;
using System.Windows;

namespace Geometrie
{
    public partial class ResultatPage : Page
    {
        private List<(string questionText, string userAnswer, string correctAnswer, string detailedCalculation)> recapitulatif;
        private ClasseCalcul calcul = new ClasseCalcul();

        // Constructeur
        public ResultatPage(int bonnesReponses, List<(string questionText, string userAnswer, string correctAnswer, string detailedCalculation)> recapitulatif)
        {
            InitializeComponent();

            this.recapitulatif = recapitulatif;

            // Afficher le score
            TxtScore.Text = $"Tu as obtenu {bonnesReponses} / 20 🎉";

            // Message personnalisé en fonction du score
            if (bonnesReponses == 20)
                TxtMessage.Text = "Parfait ! 👑";
            else if (bonnesReponses >= 15)
                TxtMessage.Text = "Excellent travail ! 🌟";
            else if (bonnesReponses >= 10)
                TxtMessage.Text = "Pas mal ! Continue comme ça ! 💪";
            else
                TxtMessage.Text = "Tu peux faire mieux ! Réessaie 😊";
        }

        private void BtnAccueil_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();

            // Fermer la fenêtre actuelle (celle qui contient la page AccueilPage)
            Window.GetWindow(this)?.Close();
        }

        private void BtnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void BtnVoirRecap_Click(object sender, RoutedEventArgs e)
        {
            // Pour la page de récapitulatifs, utiliser ClasseCalcul pour simuler les calculs
            List<(string questionText, string userAnswer, string correctAnswer, string detailedCalculation)> recapWithCalculations = new List<(string questionText, string userAnswer, string correctAnswer, string detailedCalculation)>();

            foreach (var item in recapitulatif)
            {
                string detailedCalculation = item.detailedCalculation;

                // Exemple : si un calcul est nécessaire, on le modifie avec ClasseCalcul
                if (detailedCalculation.Contains("x"))
                {
                    int randomValue = calcul.Init();
                    detailedCalculation += $" => Exemple de calcul avec valeur aléatoire : {randomValue}";
                }

                recapWithCalculations.Add((item.questionText, item.userAnswer, item.correctAnswer, detailedCalculation));
            }

            // Naviguer vers la page des récapitulatifs en passant les données réelles
            RecapitulatifPage recapitulatifPage = new RecapitulatifPage(recapWithCalculations);
            NavigationService.Navigate(recapitulatifPage);
        }

        private void NavigationFrame_Navigated(object sender, NavigationEventArgs e)
        {

        }
    }
}
