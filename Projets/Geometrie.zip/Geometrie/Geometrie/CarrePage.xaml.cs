﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace Geometrie
{
    public partial class CarrePage : Page
    {
        ClasseCarre carre = new ClasseCarre();
        public CarrePage()
        {
            InitializeComponent();
            carre.Init();
            TxtCote.Text = carre.UneValeur.ToString();  // Assigner la valeur de UneValeur à TxtCote
        }

        private void DrawingCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            ClasseCarre carre = new ClasseCarre();
            carre.Init();
            TxtCote.Text = carre.UneValeur.ToString();
            carre.Dessin(DrawingCanvas,TxtCote);  // Méthode pour dessiner le carré, à implémenter
        }

        private void BtnVerifierPerimetre_Click(object sender, RoutedEventArgs e)
        {
            ClasseCarre carre = new ClasseCarre();
            carre.Init();

            try
            {
                // Conversion du côté
                int cote = Convert.ToInt32(TxtCote.Text);
                carre.UneValeur = cote;

                // Calcul du périmètre et arrondi à l'entier le plus proche
                int perimetreCorrect = Convert.ToInt16(carre.Perimetre());

                // Conversion de la valeur entrée par l'utilisateur
                int perimetreUtilisateur = Convert.ToInt32(TxtPerimetre.Text);

                // Vérification du périmètre
                if (perimetreCorrect == perimetreUtilisateur)
                {
                    TxtBlockResultatPerimetre.Text = "Bonne réponse !";
                    TxtBlockResultatPerimetre.Foreground = System.Windows.Media.Brushes.Green;
                }
                else
                {
                    TxtBlockResultatPerimetre.Text = "Mauvaise réponse !";
                    TxtBlockResultatPerimetre.Foreground = System.Windows.Media.Brushes.Red;
                }
                TxtBlockResultatPerimetre.Visibility = Visibility.Visible;
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez entrer un côté ou un périmètre valide.");
            }
        }

        private void BtnVerifierSurface_Click(object sender, RoutedEventArgs e)
        {
            ClasseCarre carre = new ClasseCarre();
            carre.Init();

            try
            {
                int cote = Convert.ToInt32(TxtCote.Text);
                carre.UneValeur = cote;
                int surfaceCorrecte = Convert.ToInt16(carre.Surface());

                int surfaceUtilisateur = Convert.ToInt32(TxtSurface.Text);
                if (surfaceCorrecte == surfaceUtilisateur)
                {
                    TxtBlockResultatSurface.Text = "Bonne réponse !";
                    TxtBlockResultatSurface.Foreground = System.Windows.Media.Brushes.Green;
                }
                else
                {
                    TxtBlockResultatSurface.Text = $"Mauvaise réponse !";
                    TxtBlockResultatSurface.Foreground = System.Windows.Media.Brushes.Red;
                }
                TxtBlockResultatSurface.Visibility = Visibility.Visible;
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez entrer un côté ou une surface valide.");
            }
        }

        private void BtnChangerCote_Click(object sender, RoutedEventArgs e)
        {
            TxtPerimetre.Clear();
            TxtSurface.Clear();
            TxtBlockResultatPerimetre.Visibility = Visibility.Hidden;
            TxtBlockResultatSurface.Visibility = Visibility.Hidden;
            ClasseCarre carre = new ClasseCarre();
            carre.Init();

            TxtCote.Text = carre.UneValeur.ToString();

            carre.Dessin(DrawingCanvas, TxtCote);
        }

        private void BtnIndicePerimetre_Click(object sender, RoutedEventArgs e)
        {
            TxtPerimetre.Text = "4 × Côté"; // Affiche l'indice pour le périmètre
        }

        private void BtnIndiceSurface_Click(object sender, RoutedEventArgs e)
        {
            TxtSurface.Text = "Côté × Côté"; // Affiche l'indice pour la surface
        }
        private void TxtPerimetre_GotFocus(object sender, RoutedEventArgs e)
        {
            // Efface le texte de la TextBox lorsque l'utilisateur clique dedans si elle contient l'indice
            if (TxtPerimetre.Text == "4 × Côté")
            {
                TxtPerimetre.Clear();
            }
        }

        private void TxtSurface_GotFocus(object sender, RoutedEventArgs e)
        {
            // Efface le texte de la TextBox lorsque l'utilisateur clique dedans si elle contient l'indice
            if (TxtSurface.Text == "Côté × Côté")
            {
                TxtSurface.Clear();
            }
        }

        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            mainWindow.NavigationFrame.Navigate(new AccueilPage());

        }

        private void BtnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown(); // Fermer l'application
        }
    }
}
